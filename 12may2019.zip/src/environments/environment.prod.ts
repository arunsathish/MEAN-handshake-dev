export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyD04OZ8yUpz6QHD3Dg3BtK-FZO7YXsaa1A",
    authDomain: "handshake-d.firebaseapp.com",
    projectId: "handshake-d",
    storageBucket: "handshake-d.appspot.com",
    messagingSenderId: "1042946851752"
  },
  googleClientID: "1042946851752-nh6mtu3jdv1d1ga2547p7adduivet13v.apps.googleusercontent.com",
  nodeUrl: "http://handshakedev.us-east-2.elasticbeanstalk.com"
};
